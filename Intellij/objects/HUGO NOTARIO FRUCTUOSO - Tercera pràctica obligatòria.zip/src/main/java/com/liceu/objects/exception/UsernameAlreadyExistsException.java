package com.liceu.objects.exception;

public class UsernameAlreadyExistsException extends RuntimeException {
}
