package com.liceu.objects.exception;

public class IncorrectPasswordOrUsernameException extends RuntimeException {

}
