package com.liceu.objects.exception;

public class ObjectAlreadyExistsException extends RuntimeException {
}
