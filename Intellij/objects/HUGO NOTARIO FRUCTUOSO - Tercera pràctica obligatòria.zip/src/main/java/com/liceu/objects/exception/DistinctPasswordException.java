package com.liceu.objects.exception;

public class DistinctPasswordException extends RuntimeException {
}
